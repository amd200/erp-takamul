import json, sys, os
root = sys.argv[1]
AR = {"tools": "أدوات العميل", "customer": "العميل", "companion": "إضافة / تعديل مرافق", "measurements": "مقاسات العميل", "movement": "حركة العميل",
      "receipt": "سند قبض", "addCustomer": "اضافة عميل", "editCustomer": "تعديل العميل", "pickToEdit": "اختر عميل لتعديله",
      "searchCustomer": "ابحث عن عميل...", "selectedMeasurement": "المقاس المختار"}
EN = {"tools": "Customer tools", "customer": "Customer", "companion": "Add / edit companion", "measurements": "Customer measurements", "movement": "Customer movement",
      "receipt": "Receipt Bond", "addCustomer": "Add Customer", "editCustomer": "Edit Customer", "pickToEdit": "Choose a customer to edit",
      "searchCustomer": "Search for a customer...", "selectedMeasurement": "Selected measurement"}
for lang, block in (("ar", AR), ("en", EN)):
    p = os.path.join(root, f"{lang}.json")
    d = json.load(open(p, encoding="utf-8"))
    d["pos"]["optics"] = block
    open(p, "w", encoding="utf-8", newline="\n").write(json.dumps(d, ensure_ascii=False, indent=2) + "\n")
print("ok")
